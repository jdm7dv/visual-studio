// CSharpNode.cs
//
// Andrew Bradnan 2010
// andrew.bradnan@gmail.com

using Antlr.Runtime.Tree;
using Antlr.Runtime;
using System.Diagnostics;
using Symbol;

[DebuggerDisplay("var={Id}")]
public class CSharpNode : CommonTree
{
    public IScope<CSharpNode> Scope;   // set by Def.g; ID lives in which scope?
    public Symbol<CSharpNode> Symbol; // set by Ref.g; point at def in symbol table
    #region public string Id
    protected string id = string.Empty;
    public string Id
    {
        get
        {
            if (id.Length < 1)
                return string.Empty;

            // trim last char if it's a '.'
            if (id[id.Length - 1] == '.')
                return id.Substring(0, id.Length - 1);
            else
                return id;
        }
        set
        {
            id = value;
        }
    }
    public void AddId(string id)
    {
        if (id != null && id != string.Empty)
            this.id += id + ".";
    }
    #endregion
    
    public CSharpNode() : base() { }
	
    [DebuggerStepThrough()]
	public CSharpNode(IToken t)
		: base(t)
	{
	}
    public override string ToString()
    {
        return Id;
    }
    public void Resolve(bool search_global)
    {
	    Symbol = Scope.Resolve(Id, search_global, Line);
    }
    public void ResolveType(bool search_global)
    {
   		Symbol.Type = (ISymbolType)Scope.Resolve(Id, search_global);
    }
}
