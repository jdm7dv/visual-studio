*** WARNING ***
This project uses Tree Pattern Matching, which was added to ANTLR 3.2.  The CSharp 3.1 runtime has no support for 
Tree Pattern Matching.  There is no CSharp 3.2 Runtime :)  There will not be a CSharp 3.2 Runtime.

Build Instructions:
- To build this project from the .g grammar files you must use the included antlr-3.3.jar.  The antlr-3.2.jar does 
not have string templates (used to generate the parser/lexer) that work with the updated runtime.  Your 
parser/lexer will not compile if you do not use the included antlr3.3.jar.
- You must use this solution's custom Antlr3.Runtime (already done for you).  This is a snapshot of the source, with
bug fixes I have made.  The runtime pieces I use seem to work just fine.  YMMV if you use others.  Good luck with that :)