// SymbolTable.cs
//
// Andrew Bradnan 2009-2010
// andrew.bradnan@gmail.com

using Symbol;

public class SymbolTable
{
    public Scope<CSharpNode> globals = new Scope<CSharpNode>(null, "global");
//    ClassSymbol objectRoot;

    public SymbolTable() { InitTypeSystem(); }

    protected void InitTypeSystem()
    {
        // if you wanted a predefined Object class hierarchy root
        // like Java, you'd define it here:
/*
        objectRoot = new ClassSymbol("Object", globals, null);
        MethodSymbol hashCode = new MethodSymbol("hashCode",new BuiltInTypeSymbol("int"),objectRoot);
        objectRoot.define(hashCode);
        globals.define(objectRoot);
*/
        // define predefined atomic types
        globals.Define(new BuiltInTypeSymbol<CSharpNode>("int"));
        globals.Define(new BuiltInTypeSymbol<CSharpNode>("float"));
        globals.Define(new BuiltInTypeSymbol<CSharpNode>("void")); // pseudo-type
        globals.Define(new BuiltInTypeSymbol<CSharpNode>("string"));
    }

    /** 'this' and 'super' need to know about enclosing class */
    public static ClassSymbol<CSharpNode> GetEnclosingClass(IScope<CSharpNode> s) 
	{
        while (s != null)
		{
			// walk upwards from s looking for a class
            if (s is ClassSymbol<CSharpNode>) 
				return (ClassSymbol<CSharpNode>)s;
            s = s.EnclosingScope;
        }
        return null;
    }

    public override string ToString() 
	{ 
		return globals.ToString();
	}
}
