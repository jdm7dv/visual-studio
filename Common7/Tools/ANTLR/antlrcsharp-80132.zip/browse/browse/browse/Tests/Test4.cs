 //#pragma checksum "..\..\Window1.xaml" "{406ea660-64cf-4c82-b6f0-42d48172a799}" "4D5C2DB46D4AEBF3CE9D342012AD1775"
//@null = new WriteStream(entry, isThrow, contentLength, this.async);
//                    case '"':
//                    case '“':
//                    case '”':
//                    object[] args = new object[] { 100.ToString(CultureInfo.InstalledUICulture), discardedSinceLastFlush.ToString(CultureInfo.InstalledUICulture), lastFlush.ToString("r", CultureInfo.InstalledUICulture) };
//
//
//using System;
//using System.Collections;
//using System.IO;
//using System.Drawing;
//using System.Windows.Forms;
//using System.Xml;


namespace JetBrains.Omea.OpenAPI
{
    public class SomeBaseClass
    {
        public int y;
    }
    public class A
    {
        B b;
    }
    public class B
    {
        C c;
    }
    public class C
    {
        int d;
    }


    public class DisplayPaneCommands 
        : SomeBaseClass //, interface_undef1, interface_undef2    // interface1, interface2 not found
    {
        public int interface1.Forward, Backward, x;
        string Foo()
        {
            A a;
            BOGUS b;
            a.b.c.d = 42;
            this.x = 42;
            this.y = 43;
            this.u = 34;    // u is undefined
            y = 44;
            u = 44;         // u is not defined
        }
        void Bar(int x, int y, int z)
        {
            SomeBaseClass some;
            x = 42;
            this.x = x;
        }
/*        public const string Forward;
        public string Forward		   = "Backwards";
        public const double Sideways   = 1234;
        public const string Sideways   = 1.234;
        public const string Sideways   = 1.234f;
        public const string Sideways   = 0x1234;
// need expressions for this
//        public const string Back       = 0.ToString();            
        public const string Back       = null;
        public const string FindInPage = "FindInPage";
        public const string Cut        = "Cut";
        public const string Copy       = "Copy";
        public const string Paste      = "Paste";
        public const string Print      = "Print";
        public const string PageDown   = "PageDown";
        public const string SelectAll  = "SelectAll";
        public const string RenameSelection = "RenameSelection";
        public const string NextSearchResult = "NextSearchResult";
        public const string PrevSearchResult = "PrevSearchResult";
   */   
    }
}

