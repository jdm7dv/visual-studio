(numer / denom)
//()
//("foobar")
//("foobar", 2)

