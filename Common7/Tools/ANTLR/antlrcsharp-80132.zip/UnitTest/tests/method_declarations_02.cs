string Foo() { }
public string Foo() { ; }
public static string Foo();
public override string Foo();
public override frank[] Foo();
internal unsafe void* BaseAddress();
public override frank[] Foo(Spam spam='foo');
//public override object this[string keyword];
