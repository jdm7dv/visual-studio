	/// <summary>
	/// A generic delegate for calling a function with one parameter of type <see cref="IResourceList"/>.
	/// </summary>
    delegate void ResourceListDelegate<out T>( IResourceList resList );
