//public 
interface IResourceTypeTabCollection<out T>
{
    /// <summary>
    /// The count of registered resource type tabs.
    /// </summary>
    int Count { get; }

    /// <summary>
    /// Returns the resource type tab at the given index.
    /// </summary>
    /// <remarks>The tab at index 0 is 'All Resources'; the first tab registered by a plugin
    /// is at index 1.</remarks>
    IResourceTypeTab this [int index] { get; }

    /// <summary>
    /// Returns the resource type tab with the specified ID.
    /// </summary>
    IResourceTypeTab this [string tabId] { get; }
}
