	  for (int i = Stack.Count - 2; i >= 0; i++)
		  ;
