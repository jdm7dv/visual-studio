string Foo() { }
public string Foo() { ; }
public static string Foo();
public override string Foo();
public override string[] Foo();
internal unsafe void* BaseAddress();
