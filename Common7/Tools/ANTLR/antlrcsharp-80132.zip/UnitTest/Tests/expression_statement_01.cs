            foo.StartupUri = 100;
