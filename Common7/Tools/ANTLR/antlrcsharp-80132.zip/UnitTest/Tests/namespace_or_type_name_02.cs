ICollection<Type>.Foo
