	ICollection<Type>.CopyTo(Array array, int index)
	{
	    ((ICollection)_storage).CopyTo(array, index);
	}
