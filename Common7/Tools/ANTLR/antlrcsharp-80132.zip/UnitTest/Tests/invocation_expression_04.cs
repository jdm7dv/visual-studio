doc.LoadXml((int)foo)

