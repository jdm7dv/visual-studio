public string Foo;
public tring[] Foo;
public string[] Foo = 0;
public string Foo,Bar;
internal unsafe void* BaseAddress;

// We need "expression" for these next tests.
//public const string Foo = string.Empty;
//public const string Foo = 0.ToString();
