while (true) 
	foo.bar;

