Path.GetFileName(args);
base.foo(one, two);

