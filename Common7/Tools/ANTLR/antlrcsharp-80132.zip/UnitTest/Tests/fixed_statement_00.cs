fixed(byte* b = basePtr) 
{
    IntPtr currentPtr = new IntPtr( (vsoid *) b); 
}
