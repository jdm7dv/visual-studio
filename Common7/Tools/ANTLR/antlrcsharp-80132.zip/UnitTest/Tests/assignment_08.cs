searchPattern = Path.GetFileName = "foo"
