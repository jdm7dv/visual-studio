WordPtr[] words
