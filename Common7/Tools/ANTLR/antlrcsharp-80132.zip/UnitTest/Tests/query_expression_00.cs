    from student in students
    where student.Scores[0] < 90
    select student
    
