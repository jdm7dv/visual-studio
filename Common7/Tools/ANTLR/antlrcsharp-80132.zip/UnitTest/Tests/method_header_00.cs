Foo(int x)
