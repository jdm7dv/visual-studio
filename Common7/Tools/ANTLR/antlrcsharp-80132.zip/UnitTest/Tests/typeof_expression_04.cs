typeof(foo<>)
