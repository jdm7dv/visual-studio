string Foo();
public string Foo();
public static string Foo();
public override string Foo();
void ICollection.CopyTo(Array array, int index)
	{
	    ((ICollection)_storage).CopyTo(array, index);
	}
