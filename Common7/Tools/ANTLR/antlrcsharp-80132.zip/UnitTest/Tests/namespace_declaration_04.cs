namespace JetBrains.Omea.OpenAPI
{
	public class Foo
	{
		static string[] _foo;
		static void Main(string[] args)
		{
		}
	}
	public class Bar
	{
	}
}