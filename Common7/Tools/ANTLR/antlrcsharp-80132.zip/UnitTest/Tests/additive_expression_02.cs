//edges[i].p1Transformed + numer / FOO 
edges[i].p1Transformed + (number / foo)
