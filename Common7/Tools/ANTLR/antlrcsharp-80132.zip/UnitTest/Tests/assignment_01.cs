            foo.StartupUri = 100
