	/// <summary>
    /// Specifies a format of a plain or rich text string.
    /// </summary>
        /// <summary>
        /// The string contains plain text.
        /// </summary>
        PlainText
