(ref (int) ref foo)

