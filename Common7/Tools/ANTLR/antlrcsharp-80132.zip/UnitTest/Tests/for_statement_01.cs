for (int i = buckets[bucket]; i >= 0; last = i, i = entries[i].next)
	;
