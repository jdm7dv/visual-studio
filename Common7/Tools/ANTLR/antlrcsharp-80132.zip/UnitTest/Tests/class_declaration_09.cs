class NullableComparer where T : Comparer<WTF<T>>
{

}
