global::ICollection<Type>
