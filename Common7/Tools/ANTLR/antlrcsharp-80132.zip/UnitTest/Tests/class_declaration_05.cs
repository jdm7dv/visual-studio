    class App : System.Windows.Application {
        
    public EventHandler<ParserFoo> ActionSelected;
    public event EventHandler<ParserActionEventArgs> ActionSelected;
//        [System.Diagnostics.DebuggerNonUserCodeAttribute()]
        public void InitializeComponent() {
            
//            #line 18 "..\..\App.xaml"
//            this.StartupUri = new System.Uri("DemoWindow.xaml", System.UriKind.Relative);
            
//            #line default
//            #line hidden
        }
	}