// Copyright (c) Microsoft Corporation. All rights reserved.

                    #if !ISOLATION_IN_MSCORLIB
                    #define FEATURE_COMINTEROP
                    #endif
    using System; 
    using System.IO;
    using System.Runtime.InteropServices; 
    using System.Collections; 
    using System.Globalization;
    using System.Threading; 

internal static class Win32Native {
#if !FEATURE_PAL
#else // !FEATURE_PAL

#if !PLATFORM_UNIX 
 //       //internal const String DLLPREFIX = "";
 //       //internal const String DLLSUFFIX = ".dll"; 
#else // !PLATFORM_UNIX
#if __APPLE__
 //       //internal const String DLLPREFIX = "lib";
 //       //internal const String DLLSUFFIX = ".dylib"; 
 // #elif _AIX
 //       //internal const String DLLPREFIX = "lib";
 //       //internal const String DLLSUFFIX = ".a"; 
#elif __hppa__ || IA64
 //       //internal const String DLLPREFIX = "lib"; 
 //       //internal const String DLLSUFFIX = ".sl";
 // #else
 //       //internal const String DLLPREFIX = "lib";
 //       //internal const String DLLSUFFIX = ".so"; 
#endif
#endif // !PLATFORM_UNIX 
#endif
}

