    //public 
    interface IPlugin
    {
        void Register();
        void Startup();
        void Shutdown();
    }
