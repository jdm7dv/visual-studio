// IResourceTypeTab 
this [int index] { get; }
