    class App : System.Windows.Application {
        
//        [System.Diagnostics.DebuggerNonUserCodeAttribute()]
        public void InitializeComponent() {
            
//            #line 18 "..\..\App.xaml"
//            this.StartupUri = new System.Uri("DemoWindow.xaml", System.UriKind.Relative);
            
//            #line default
//            #line hidden
        }
	}