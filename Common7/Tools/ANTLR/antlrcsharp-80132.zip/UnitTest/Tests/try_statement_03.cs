try
{
	int local = Path.Foo();
	Model3DGroup @group = model as Model3DGroup;
	while(true)
	{
	}
}
catch (System.IndexOutOfRangeException)
{
}
catch(Exception)
{
}
catch
{
}
finally
{
}