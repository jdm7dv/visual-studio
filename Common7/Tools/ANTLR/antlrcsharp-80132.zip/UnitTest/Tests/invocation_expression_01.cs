string.Intern(symbol)

