	{
	    ((ICollection)_storage).CopyTo(array, index);
	}
