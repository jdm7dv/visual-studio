new Point3D[] {
    new Point3D(x1, y1, z1),
    new Point3D(x1, y1, z2),
    new Point3D(x1, y2, z1),
    new Point3D(x1, y2, z2),
    new Point3D(x2, y1, z1),
    new Point3D(x2, y1, z2),
    new Point3D(x2, y2, z1),
    new Point3D(x2, y2, z2),
}
