doc.LoadXml(new StreamReader(context.Request.InputStream).ReadToEnd())

