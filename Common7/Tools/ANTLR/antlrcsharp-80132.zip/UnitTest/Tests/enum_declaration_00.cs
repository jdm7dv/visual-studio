	/// <summary>
    /// Specifies a format of a plain or rich text string.
    /// </summary>
    //public
    enum TextFormat 
    {
        /// <summary>
        /// The string contains plain text.
        /// </summary>
        PlainText, 
        
        /// <summary>
        /// The string is a valid HTML fragment.
        /// </summary>
        Html, 
        
        /// <summary>
        /// The string contains rich text in the RTF format.
        // </summary>
        Rtf ,
    }
