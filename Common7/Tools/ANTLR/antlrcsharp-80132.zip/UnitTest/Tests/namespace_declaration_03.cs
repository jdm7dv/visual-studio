namespace JetBrains.Omea.OpenAPI
{
	public class Foo
	{
		static int[] foo;
		static void Main()
		{
		}
	}
}