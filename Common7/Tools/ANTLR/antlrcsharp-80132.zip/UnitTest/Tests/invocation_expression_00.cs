Path.Foo()
