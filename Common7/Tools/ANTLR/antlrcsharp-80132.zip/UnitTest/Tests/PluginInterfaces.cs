﻿using System;
using System.Collections;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using System.Xml;

namespace JetBrains.Omea.OpenAPI
{
    public enum TextFormat 
    {
        PlainText, 
        Html, 
        Rtf 
    };
    public interface IPlugin
    {
        void Register();
        void Startup();
        void Shutdown();
    }
    public interface IResourceDisplayer
    {
        IDisplayPane CreateDisplayPane( string resourceType );
    }
    public interface ICommandProcessor : IFoo, IBar
    {
        bool CanExecuteCommand( string command );
        void ExecuteCommand( string command );
    }
    public interface IDisplayPane: ICommandProcessor
    {
        Control GetControl();
        void DisplayResource( IResource resource );
//		[ Obsolete( "Use the IDisplayPane2.HighlightWords(IResource, WordPtr[]) overload instead.", false ) ]
        void HighlightWords( WordPtr[] words );
        void EndDisplayResource( IResource resource );
        void DisposePane();
        string GetSelectedText( ref TextFormat format );
        string GetSelectedPlainText();
    }
    public interface IDisplayPane2 : IDisplayPane
    {
        void DisplayResource( IResource resource, WordPtr[] wordsToHighlight );
    }
    public interface IResourceTextProvider
    {
        bool ProcessResourceText( IResource res, IResourceTextConsumer consumer );
    }
    public interface IResourceTextIndexingPermitter
    {
        bool CanIndexResource( IResource res );
    }
    public interface IResourceIconProvider
    {
        Icon GetResourceIcon( IResource resource );
        Icon GetDefaultIcon( string resType );
    }
    public interface IOverlayIconProvider
    {
        Icon[] GetOverlayIcons( IResource res );
    }
    public interface IStreamProvider
    {
        Stream GetResourceStream( IResource resource );
    }

    public class DisplayPaneCommands
    {
        public const string Sideways   = "foo";
        public const string Back       = "Back";
        public const string Forward    = "Forward";
        public const string FindInPage = "FindInPage";
        public const string Cut        = "Cut";
        public const string Copy       = "Copy";
        public const string Paste      = "Paste";
        public const string Print      = "Print";
        public const string PageDown   = "PageDown";
        public const string SelectAll  = "SelectAll";
        public const string RenameSelection = "RenameSelection";
        public const string NextSearchResult = "NextSearchResult";
        public const string PrevSearchResult = "PrevSearchResult";
    }
    public interface IResourceUIHandler
    {
        void ResourceNodeSelected( IResource res );
        bool CanRenameResource( IResource res );
        bool ResourceRenamed( IResource res, string newName );
        bool CanDropResources( IResource targetResource, IResourceList dragResources );
        void ResourcesDropped( IResource targetResource, IResourceList droppedResources );
    }
    public interface IResourceDragDropHandler
    {
        void AddResourceDragData( IResourceList dragResources, IDataObject dataObject );
        DragDropEffects DragOver( IResource targetResource, IDataObject data, DragDropEffects allowedEffect,
            int keyState );
        void Drop( IResource targetResource, IDataObject data, DragDropEffects allowedEffect, int keyState );
    }
    public interface IResourceRenameHandler
    {
        bool CanRenameResource( IResource res, ref string editText );
        bool ResourceRenamed( IResource res, string newName );
    }
    public enum ThreadExpandReason
    {
        Enumerate,        
        Expand
    }
    public interface IResourceThreadingHandler
    {
        IResource GetThreadParent( IResource res );
        IResourceList GetThreadChildren( IResource res );
        bool IsThreadChanged( IResource res, IPropertyChangeSet changeSet );
        bool CanExpandThread( IResource res, ThreadExpandReason reason );
        bool HandleThreadExpand( IResource res, ThreadExpandReason reason );
    }
    public interface ICustomColumn
    {
        void Draw( IResource res, Graphics g, Rectangle rc );
        void DrawHeader( Graphics g, Rectangle rc );
        void MouseClicked( IResource res, Point pt );
        bool ShowContextMenu( IActionContext context, Control ownerControl, Point pt );
        string GetTooltip( IResource res );
    }
    public enum SerializationMode
    {
        Default,
        NoSerialize,
        AskSerialize,
        Serialize
    }
    public interface IResourceSerializer
    {
        void AfterSerialize( IResource parentResource, IResource res, XmlNode node );
        IResource AfterDeserialize( IResource parentResource, IResource res, XmlNode node );
        SerializationMode GetSerializationMode( IResource res, string propertyType );
    }
    public interface IResourceDeleter
    {
        DialogResult ConfirmDeleteResources( IResourceList resources, bool permanent, bool showCancel );
        bool CanDeleteResource( IResource res, bool permanent );
        bool CanIgnoreRecyclebin();
        void DeleteResource( IResource res );
        void DeleteResourcePermanent( IResource res );
        void UndeleteResource( IResource res );
    }
    public interface INewspaperProvider
    {
        void GetHeaderStyles( string resourceType, TextWriter writer );
        void GetItemHtml( IResource item, TextWriter writer );
    }

    public delegate void ResourceDelegate( IResource res );
    public delegate void ResourceListDelegate( IResourceList resList );
	public enum StatusPane
	{
		UI,
		Network, 
		ResourceBrowser
	};
    public interface IUnreadCountProvider
    {
        IResourceList GetResourcesForView( IResource viewResource );
    }
    public interface IUnreadManager
    {
        void RegisterUnreadCountProvider( string resType, IUnreadCountProvider provider );
        int GetUnreadCount( IResource res );
        void InvalidateUnreadCounter( IResource res );
    }
    public interface IProgressWindow
    {
        void UpdateProgress( int percentage, string message, string timeMessage );
    }
    public interface IStatusWriter
    {
        void ShowStatus( string message );
        void ShowStatus( string message, bool repaint );
        void ClearStatus();
        string LastMessage{ get; }
		void ShowStatus(string message, int nSecondsToKeep);
    }
    public interface IResourceNodeFilter
    {
        bool AcceptNode( IResource res, int level );
    }
    public interface IResourceTreePane
    {
        void RegisterToolbarAction( IAction action, Icon icon, string text, string tooltip, 
            IActionStateFilter[] filters );
        void RegisterToolbarAction( IAction action, Image icon, string text, string tooltip, 
            IActionStateFilter[] filters );
        void AddNodeFilter( IResourceNodeFilter nodeFilter );
        void UpdateNodeFilter( bool keepSelection );
        void SelectResource( IResource res );
        void EditResourceLabel( IResource res );
        void ExpandParents( IResource res );
//        [Obsolete]
        void EnableDropOnEmpty( IResourceUIHandler emptyDropHandler );
        void EnableDropOnEmpty( IResourceDragDropHandler emptyDropHandler );
        bool SelectAddedItems { get; set; }
        int ParentProperty { get; set; }
        string[] WorkspaceFilterTypes { get; set; }
        IResource SelectedNode { get; }
        ResourceToolTipCallback ToolTipCallback { get; set; }
    }
    public delegate string ResourceToolTipCallback( IResource res );
    public interface ISidebar
    {
        void RegisterPane( AbstractViewPane viewPane, string paneId, string caption, Image icon );
        void SetPaneCaption( string paneId, string caption );
        bool IsPaneExpanded( string paneId );
        void SetPaneExpanded( string paneId, bool expanded );
        int PanesCount { get; }
        AbstractViewPane GetPane( string name );
    }
    public interface ISidebarSwitcher
    {
        void RegisterViewPane( string paneId, string tabId, string caption, Image icon, AbstractViewPane viewPane );
        IResourceTreePane RegisterTreeViewPane( string paneId, string tabId, string caption, Image icon, 
                                                IResource rootResource );
        void RegisterResourceStructurePane( string paneId, string tabId, string caption, Image icon, 
                                            AbstractViewPane viewPane );
        IResourceTreePane RegisterResourceStructureTreePane( string paneId, string tabId, string caption, 
                                                             Image icon, IResource rootResource );
        IResourceTreePane RegisterResourceStructureTreePane( string paneId, string tabId, string caption, 
                                                             Image icon, string rootResType );
        void RegisterViewPaneShortcut( string paneId, Keys shortcut );
        IResourceTreePane DefaultViewPane { get; }
        void ActivateViewPane( string paneId );
        AbstractViewPane ActivateViewPane( string tabId, string paneId );
        string ActivePaneId { get; }
        AbstractViewPane GetPane( string paneId );
        AbstractViewPane GetPane( string tabId, string paneId );
        string GetResourceStructurePaneId( string tabId );
    }
    public interface IResourceTypeTab
    {
        string Id { get; }        
        string Name { get; }
        string[] GetResourceTypes();
        int LinkPropId { get; }
        IResourceList GetFilterList( bool live );
    }
    public interface IResourceTypeTabCollection
    {
        int Count { get; }
        IResourceTypeTab this [int index] { get; }
        IResourceTypeTab this [string tabId] { get; }
    }
    public interface ITabManager
    {
        IResourceTypeTabCollection Tabs { get; }
        void RegisterResourceTypeTab( string tabId, string tabName, string resType, int order );
        void RegisterResourceTypeTab( string tabId, string tabName, string[] resTypes, int order );
        void RegisterResourceTypeTab( string tabId, string tabName, string[] resTypes, int linkPropId, 
            int order );
        void SetDefaultSelectedResource( string tabId, IResource res );
        void SelectResourceTypeTab( string resType );
        void SelectLinkPropTab( int linkPropId );
        string FindResourceTypeTab( string resType );
        string FindLinkPropTab( int linkPropId );
        string CurrentTabId { get; set; }
        IResourceTypeTab CurrentTab { get; }
        bool ActivateTab( string tabId );
        string GetResourceTab( IResource res );
        event EventHandler TabChanged;
    }
    public class StandardViewPanes
    {
        public const string ViewsCategories = "ViewsCategories";
        public const string Correspondents = "Correspondents";
    }
    public interface IContextProvider
    {
        IActionContext GetContext( ActionContextKind kind );
    }
    [Flags]
    public enum MultiLineColumnFlags
    {
        AnchorLeft = 1, 
        AnchorRight = 2,
        HideIfNoProp = 4
    }
    public interface IResourceGroupProvider
    {
        string GetGroupName( IResource res );
    }
    public interface IDisplayColumnManager
    {
        void RegisterDisplayColumn( string resourceType, int index, ColumnDescriptor column );
        void RegisterAvailableColumn( string resourceType, ColumnDescriptor column );
        void RemoveAvailableColumn( string resourceType, string propName );
        void RegisterCustomColumn( int propId, ICustomColumn customColumn );
        void RegisterMultiLineColumn( string resourceType, int propId, int startRow, int endRow,
            int startX, int width, MultiLineColumnFlags flags, Color textColor, HorizontalAlignment textAlign );
        void RegisterMultiLineColumn( string resourceType, int[] propIds, int startRow, int endRow,
            int startX, int width, MultiLineColumnFlags flags, Color textColor, HorizontalAlignment textAlign );
        void SetAlignTopLevelItems( string resourceType, bool align );
        void RegisterPropertyToTextCallback( int propId, PropertyToTextCallback propToText );
        void RegisterPropertyToTextCallback( int propId, PropertyToTextCallback2 propToText );
        ColumnDescriptor[] GetDefaultColumns( IResourceList resList );
        ColumnDescriptor[] AddAnyTypeColumns( ColumnDescriptor[] columnDescriptors );
    }
    public interface ISettingStore
    {
        void WriteString( string section, string key, string value );
        void WriteInt( string section, string key, int value );
        void WriteBool( string section, string key, bool value );
        void WriteDate( string section, string key, DateTime value );
        string ReadString( string section, string key );
        string ReadString( string section, string key, string defaultValue );
        int ReadInt( string section, string key, int defaultValue );
        bool ReadBool( string section, string key, bool defaultValue );
        DateTime ReadDate( string section, string key, DateTime defaultValue );
    }
    public interface IPluginLoader
    {
        void RegisterResourceUIHandler( string resType, IResourceUIHandler handler );
        IResourceUIHandler GetResourceUIHandler( string resType );
        IResourceUIHandler GetResourceUIHandler( IResource res );
        void RegisterResourceDragDropHandler( string resType, IResourceDragDropHandler handler );
        IResourceDragDropHandler GetResourceDragDropHandler( IResource res );
        IResourceDragDropHandler GetResourceDragDropHandler( string resType );
        void RegisterResourceRenameHandler( string resType, IResourceRenameHandler handler );
        IResourceRenameHandler GetResourceRenameHandler( IResource res );
        void RegisterResourceThreadingHandler( string resType, IResourceThreadingHandler handler );
        void RegisterResourceThreadingHandler( int propId, IResourceThreadingHandler handler );
        void RegisterDefaultThreadingHandler( string resType, int replyProp );
        IResourceThreadingHandler GetResourceThreadingHandler( string resType );
        IResourceThreadingHandler CompositeThreadingHandler { get; }
        void RegisterResourceTextProvider( string resType, IResourceTextProvider provider );
        bool HasTypedTextProvider( string resType );
        void InvokeResourceTextProviders( IResource res, IResourceTextConsumer consumer );
        void RegisterResourceDisplayer( string resType, IResourceDisplayer displayer );
        IResourceDisplayer GetResourceDisplayer( string resType );
        void RegisterNewspaperProvider( string resType, INewspaperProvider provider );
        INewspaperProvider GetNewspaperProvider( string resType );
        void RegisterStreamProvider( string resType, IStreamProvider provider );
        IStreamProvider GetStreamProvider( string resType );
        void RegisterPluginService( object pluginService );
        object GetPluginService( Type serviceType );
        void RegisterResourceSerializer( string resType, IResourceSerializer serializer );
        IResourceSerializer GetResourceSerializer( string resType );
        void RegisterViewsConstructor( IViewsConstructor constructor );
        ArrayList GetViewsConstructors();
        void RegisterResourceDeleter( string resType, IResourceDeleter deleter );
        IResourceDeleter GetResourceDeleter( string resType );
    }
    public interface IResourceIconManager
    {
        void RegisterResourceIconProvider( string resType, IResourceIconProvider provider );
        void RegisterResourceIconProvider( string[] resTypes, IResourceIconProvider provider );
        void RegisterOverlayIconProvider( string resType, IOverlayIconProvider provider );
        IResourceIconProvider GetResourceIconProvider( string resType );
        int GetIconIndex( IResource res );
        int GetDefaultIconIndex( string resType );
        int[] GetOverlayIconIndices( IResource res );
        void RegisterPropTypeIcon( int propId, Icon icon );
        int GetPropTypeIconIndex( int propId );
        void RegisterResourceLargeIcon( string resType, Icon icon );
        Icon GetResourceLargeIcon( string resType );
        ImageList  ImageList      { get; }
        ColorDepth IconColorDepth { get; }

        Hashtable  CollectAssemblyIcons();
    }
    public enum WorkspaceResourceType
    {
        Container, 
        Filter, 
        Folder, 
        None
    }
    public interface IWorkspaceManager
    {
        void RegisterWorkspaceType( string resType, int[] linkPropIDs, WorkspaceResourceType workspaceResourceType );
        void RegisterWorkspaceContainerType( string resType, int[] linkPropIds, int recurseLinkPropId );
        void RegisterWorkspaceFolderType( string resType, string contentType, int[] linkPropIDs );
        void RegisterWorkspaceSelectorFilter( string resType, IResourceNodeFilter filter );
        void RegisterWorkspaceSelectorFilter( string resType, IResourceNodeFilter availTreeFilter,
            IResourceNodeFilter workspaceTreeFilter );
        IResource CreateWorkspace( string name );
        void DeleteWorkspace( IResource workspace );
        void AddResourceToWorkspace( IResource workspace, IResource res );
        void AddResourceToWorkspaceRecursive( IResource workspace, IResource res );
        void AddResourcesToWorkspace( IResource workspace, IResourceList resList );
        void AddToActiveWorkspace( IResource res );
        void AddToActiveWorkspaceRecursive( IResource res );
        void RemoveResourceFromWorkspace( IResource workspace, IResource res );
        void RemoveResourcesFromWorkspace( IResource workspace, IResourceList resList );
        IResourceList GetFilterList( IResource workspace );
        IResourceList GetWorkspaceResources( IResource workspace, string resType );
        IResourceList GetWorkspaceResourcesLive( IResource workspace, string resType );
        WorkspaceResourceType GetWorkspaceResourceType( string resType );
        int GetRecurseLinkPropId( string resType );
        bool IsInWorkspaceRecursive( IResource workspace, IResource res );
        IResourceList GetResourceWorkspaces( IResource resource );
        IResourceList GetAllWorkspaces();
        void SetWorkspaceTabName( string resourceType, string tabName );
        void CleanWorkspaceLinks( IResource res );
        IResource ActiveWorkspace { get; set; }
        event EventHandler WorkspaceChanged;
    }
    public interface ICategoryManager
    {
        IResourceList GetResourceCategories( IResource resource );
        void AddResourceCategory( IResource res, IResource category );
        void SetResourceCategory( IResource res, IResource category );
        void RemoveResourceCategory( IResource res, IResource category );
        IResource FindCategory( IResource parentCategory, string name );
        IResource FindOrCreateCategory( IResource parentCategory, string name );
        IResource GetRootForTypedCategory( string resType );
        IResource FindRootForTypedCategory( string resType );
        IResource RootCategory
        {
            get;
        }
        bool CheckRenameCategory( IWin32Window parentWindow, IResource category, string newName );
    }
    public interface IResourceListListener
    {
        void ResourceAdded( IResource res );
        void ResourceDeleting( IResource res );
        void ResourceChanged( IResource res, IPropertyChangeSet cs );
    }
    public interface IResourceTreeManager
    {
        IResource ResourceTreeRoot { get; }
        IResource GetRootForType( string resType );
        void LinkToResourceRoot( IResource res, int index );
        void SetResourceNodeSort( IResource node, string sortProps );
        string GetResourceNodeSort( IResource node );                      
        void SetViewsExclusive( string resType );
        bool AreViewsExclusive( string resType );
        void RegisterTreeListener( IResource parent, int parentProp, IResourceListListener listener );
        void UnregisterTreeListener( IResource parent, int parentProp, IResourceListListener listener );
    }
    public interface INotificationManager
    {
        void RegisterNotifyMeResourceType( string resType, string ruleResType );
        void RegisterNotifyMeCondition( string resType, IResource conditionTemplate, int linkPropId );
        IResource[] GetNotifyMeConditions( string resType );
        int GetConditionLinkType( string resType, IResource conditionTemplate );
        string GetRuleResourceType( string resType );
    }
    public interface IRemoteControlManager
    {
        int AddRemoteCall(string rcName, string foo);
    }
    public delegate void EditedResourceSavedDelegate( IResource res, object tag );
    public delegate void ValidateStringDelegate( string value, ref string validateErrorMessage );
}
