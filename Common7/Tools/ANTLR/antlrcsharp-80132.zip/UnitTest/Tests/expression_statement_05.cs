            this.StartupUri = 100;
