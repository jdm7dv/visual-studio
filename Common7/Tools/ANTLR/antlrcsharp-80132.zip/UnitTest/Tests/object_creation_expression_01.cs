//new
System.Uri("DemoWindow.xaml", System.UriKind.Relative)