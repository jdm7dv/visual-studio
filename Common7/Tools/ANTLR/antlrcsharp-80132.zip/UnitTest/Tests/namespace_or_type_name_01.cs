global::ICollection<Type>.Foo.Bar
