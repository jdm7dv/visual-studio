// unsafe void
GetSecuritySite( /* [out] */ void **ppSite);
