    class DisplayPaneCommands
    {	public int foo;    }
