        ~SafeHandle()
        {
            this.Dispose(false);
        }
