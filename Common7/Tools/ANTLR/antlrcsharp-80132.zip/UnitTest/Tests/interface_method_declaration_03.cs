/// <summary>
/// Returns the list of icons that should be overlaid on the specified resource.
/// </summary>
/// <param name="res">The resource for which the icons are requested.</param>
/// <returns>The array of icons, or null if no overlay icons are available.</returns>
//Icon[] GetOverlayIcons( IResource res );
GetOverlayIcons( IResource res );
//        void HighlightWords( WordPtr[] words );
