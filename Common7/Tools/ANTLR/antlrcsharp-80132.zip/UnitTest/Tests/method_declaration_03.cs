GetSecuritySite( /* [out] */ void **ppSite) {}
