    //public 
    interface IDisplayPane: ICommandProcessor
    {
        Control GetControl();
        void DisplayResource( IResource resource );
		//[ Obsolete( "Use the IDisplayPane2.HighlightWords(IResource, WordPtr[]) overload instead.", false ) ]
        void HighlightWords( WordPtr[] words );
        void EndDisplayResource( IResource resource );
        void DisposePane();
        string GetSelectedText( ref TextFormat format );
        string GetSelectedPlainText();
    }
