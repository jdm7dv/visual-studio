	/// <summary>
	/// A generic delegate for calling a function with one parameter of type <see cref="IResource"/>.
	/// </summary>
    delegate void ResourceDelegate( IResource res );

	/// <summary>
	/// A generic delegate for calling a function with one parameter of type <see cref="IResourceList"/>.
	/// </summary>
//    public delegate void ResourceListDelegate( IResourceList resList );
