doc.LoadXml(ref (int)foo)

