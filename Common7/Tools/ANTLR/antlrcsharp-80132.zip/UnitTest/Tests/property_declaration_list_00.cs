not_string Foo { set; get; }
public string Foo { public set; get; }
string[] Foo { get; set; }
public not_string Foo { set; get; }
