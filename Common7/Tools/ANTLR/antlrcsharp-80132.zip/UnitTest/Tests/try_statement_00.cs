try
{
	Path.Foo();
}
finally
{}