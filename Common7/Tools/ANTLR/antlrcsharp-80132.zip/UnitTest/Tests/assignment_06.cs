searchPattern = Path(args)
