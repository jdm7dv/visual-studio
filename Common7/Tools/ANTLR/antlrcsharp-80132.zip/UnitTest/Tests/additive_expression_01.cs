mousePos - edges[i]._p1Transformed
