string.Intern<notint>(symbol)

