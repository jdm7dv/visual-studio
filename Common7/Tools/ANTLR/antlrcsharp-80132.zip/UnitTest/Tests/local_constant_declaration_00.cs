const int minimumHelpTextColumn = 5
