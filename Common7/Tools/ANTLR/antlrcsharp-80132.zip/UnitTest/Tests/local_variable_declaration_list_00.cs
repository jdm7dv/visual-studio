			string searchPattern = (not_string)Path.GetFileName(args);
			string searchPattern = (string)Path.GetFileName(args);
			string searchPattern = Path.GetFileName(args);
			UIElement uie = (int)Mouse.Captured();
            Point[] visCorners = new Point[4];
            double visEdgeDiff = (visEdgeStart - visEdgeEnd).Length;
      Token tkn = base.TryMatch(context, source);


