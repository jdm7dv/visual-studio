_string.Intern(symbol);
