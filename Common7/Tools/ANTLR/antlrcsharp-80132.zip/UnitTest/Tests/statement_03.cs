while (true) ++i;

