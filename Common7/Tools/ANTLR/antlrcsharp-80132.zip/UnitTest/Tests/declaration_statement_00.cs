string searchPattern = Path.GetFileName(args);
