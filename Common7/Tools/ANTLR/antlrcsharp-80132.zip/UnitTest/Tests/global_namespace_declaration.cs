//global namespace test
using System;

[assembly: AssemblyTrademark("")]
[AssemblyCulture("")]	

	public class Foo
	{
		static string[] _foo;
		static void Main(string[] args)
		{
		}
	}

namespace Foo
{
	using Text;
	[DebuggerDisplay("hello")]
	public class Bar
	{
		static string[] _foo;
		static void Main(string[] args)
		{
			_foo = "bar";
		}
	}
}

namespace Bar
{
}
