    //public 
    interface IDisplayPane: ICommandProcessor
    {
        /// <summary>
        /// Returns the instance of the control which is embedded in the preview pane
        /// when the resource is displayed.
        /// </summary>
        /// <returns>The control used to display the resource.</returns>
        Control GetControl();

        /// <summary>
        /// Shows the data of the specified resource in the display pane.
        /// </summary>
        /// <param name="resource">The resource to display.</param>
        void DisplayResource( IResource resource );
        
        /// <summary>
        /// Highlights the specified search result words in the resource text.
        /// </summary>
        /// <param name="words">The array of references to words to be highlighted.</param>
        /// <remarks>
        /// <para>The array is sorted by section and then by offset within the section.</para>
        /// <para>Use the <see cref="IDisplayPane2.DisplayResource(IResource, WordPtr[])"/> overload to load the resource and request words highlighting with a single call. This provides for the optimized highlighting implementation which applies at the stage of loading the resource.</para>
        /// </remarks>
//		[ Obsolete( "Use the IDisplayPane2.HighlightWords(IResource, WordPtr[]) overload instead.", false ) ]
        void HighlightWords( WordPtr[] words );
        
        /// <summary>
        /// Ends the display of the specific resource in the display pane.
        /// </summary>
        /// <param name="resource">The resource which was displayed in the pane.</param>
        /// <remarks>After <c>EndDisplayResource</c> is called, if the user switches to a resource
        /// of the same type, <see cref="DisplayResource"/> is called to display the resource in the
        /// same display pane instance. If the user switches to a resource of a different type,
        /// <see cref="DisposePane"/> is called to dispose of the pane.</remarks>
        void EndDisplayResource( IResource resource );
        
        /// <summary>
        /// Disposes of the display pane.
        /// </summary>
        /// <remarks>After the core has called <c>DisposePane</c>, it no longer uses the pane instance.
        /// If a resource of the same type needs to be displayed again, a new pane instance is created
        /// by a call to <see cref="IResourceDisplayer.CreateDisplayPane"/>.</remarks>
        void DisposePane();

        /// <summary>
        /// Returns the text currently selected in the display pane as an RTF, HTML or plain-text
        /// string.
        /// </summary>
        /// <param name="format">The format in which the method returns the string.</param>
        /// <returns>The selected text, or null if there is no selection.</returns>
        string GetSelectedText( ref TextFormat format );

        /// <summary>
        /// Returns the text currently selected in the display pane as a plain-text string.
        /// </summary>
        /// <returns>The selected text in plain-text format, or null if there is no selection.</returns>
        string GetSelectedPlainText();
    }
