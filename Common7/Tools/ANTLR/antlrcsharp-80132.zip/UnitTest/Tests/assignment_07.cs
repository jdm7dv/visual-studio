a = b = c
