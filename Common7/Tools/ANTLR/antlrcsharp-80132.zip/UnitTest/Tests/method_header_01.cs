	ICollection.CopyTo(Array array, int index)
