/// <summary>
/// Defines additional functions for display panes.
/// </summary>
/// <since>2.0</since>
//public 
interface IDisplayPane2: IDisplayPane
{
    string Foo {get;set;}
}
