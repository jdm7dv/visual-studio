(int[])Mouse.Foo()
