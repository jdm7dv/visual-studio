    //public 
    interface IDisplayPane3 : IDisplayPane
    {
        void DisplayResource( IResource resource, WordPtr[] wordsToHighlight );
    }
