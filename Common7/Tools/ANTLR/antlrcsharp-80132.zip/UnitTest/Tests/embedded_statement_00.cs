//Path.Foo();
this.argumentMap[argument.LongName] = argument;
