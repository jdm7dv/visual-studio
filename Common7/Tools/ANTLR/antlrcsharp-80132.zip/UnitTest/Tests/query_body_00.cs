    where student.Scores[0] > 90
    select foo
    
