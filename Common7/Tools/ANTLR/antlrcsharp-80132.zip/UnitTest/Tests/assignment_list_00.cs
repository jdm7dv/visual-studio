variable = Foo.Path(args);
variable2 = (CastMe)Foo.Path;
variable3 = (CastMe)Foo.Path(args);
//visCorners[0] = gt.Transform(new Point(contBounds.Left, contBounds.Top));
//a = b = c = "foo";
//searchPattern = (Zamo)Path.GetFileName(args);
//groups = model as Model3DGroup;
//this.argumentMap[argument.LongName] = argument;
