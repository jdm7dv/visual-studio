namespace JetBrains.Omea.OpenAPI
{
}