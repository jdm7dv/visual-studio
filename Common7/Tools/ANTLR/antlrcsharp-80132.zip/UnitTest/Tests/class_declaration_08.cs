class GenericArraySortHelper 
	where TKey : new()
{

}
