//new 
System.Uri()