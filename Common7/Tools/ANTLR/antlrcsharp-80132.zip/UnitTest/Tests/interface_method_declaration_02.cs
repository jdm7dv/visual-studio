HighlightWords( WordPtr[] words );
