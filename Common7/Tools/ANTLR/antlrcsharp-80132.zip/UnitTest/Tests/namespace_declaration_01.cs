namespace JetBrains.Omea.OpenAPI
{
	[SecurityPermission(SecurityAction.LinkDemand, UnmanagedCode = true)]
	public class Foo
	{
		static int foo;
	}
}