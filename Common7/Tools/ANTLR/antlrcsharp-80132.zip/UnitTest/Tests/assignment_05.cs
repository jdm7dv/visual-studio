            this.StartupUri = 100            
