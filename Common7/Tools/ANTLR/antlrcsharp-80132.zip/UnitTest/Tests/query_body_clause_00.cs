    where student.Scores[0] > 90
    
