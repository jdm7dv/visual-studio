operator + (string phrase, GrammarBuilder builder)
