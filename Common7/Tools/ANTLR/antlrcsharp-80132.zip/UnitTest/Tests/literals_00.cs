"string"
'c'
123
0x429
0f
0l
0.345
0.234e12
0.234e12f

//("foobar")
//("foobar", 2)

