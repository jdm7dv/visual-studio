//();
1;
true;
foo;
foo.bar;
a.b.c.d.e;
foo[];
foo[0];
foo[a];
foo[ab];
foo[ab].bar;
foo[ab].bar[a];
bar[][];
bar[a][];
bar[a][b];
foo();
foo(a);
foo(a,b);
foo[0].foo();
foo[a].foo(a);
foo[ab].foo(a,b);
foo[ab].bar.foo();
foo[ab].bar[a].foo();
//(foo)bar;			// unary does casting
this.foo;
this.foo();
this.foo[0];

