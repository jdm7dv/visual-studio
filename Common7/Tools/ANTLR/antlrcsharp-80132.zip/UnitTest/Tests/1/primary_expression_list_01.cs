//();
foo;
foo.bar;
//foo->bar;
foo.bar->unsafe_member;
foo[ab]->bar;
a.b.c.d.e;
foo[];
foo[0];
foo[0](one,two,three);
foo[a];
foo[ab];
foo[ab].bar;
foo[ab].bar[a];
bar[][];
bar[a][];
bar[a][b];
foo();
foo(a);
foo(a,b);
foo[0].foo();
foo[a].foo(a);
foo[ab].foo(a,b);
foo[ab].bar.foo();
foo[ab].bar[a].foo();
//(foo);
this.foo;
this.foo();
this.foo()[4];
base.foo(one, two);
string.Intern(blah);
string.Intern<int>(blah);
StreamReader(context.Request.InputStream).ReadToEnd();
this.foo[0];
global::System.ComponentModel.EditorBrowsableAttribute(global::System.ComponentModel.EditorBrowsableState.Advanced);
typeof(foo);




new System.Uri(3,4);
new System.Uri("DemoWindow.xaml", System.UriKind.Relative);
new StreamReader(context.Request.InputStream).ReadToEnd();
//doc.LoadXml(new StreamReader(context.Request.InputStream).ReadToEnd());
((ModuleResolveEventHandler) ds[i])(this, new ResolveEventArgs(moduleName)); 
"string"[i%3];
test<asdf>;
