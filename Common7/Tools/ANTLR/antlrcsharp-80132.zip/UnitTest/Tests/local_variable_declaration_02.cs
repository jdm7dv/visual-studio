Dictionary<Guid, CachedAnnotation>.ValueCollection.Enumerator enumerator = this._currentAnnotations.Values.GetEnumerator()
