new System.Point[4].GetEnumerator()
