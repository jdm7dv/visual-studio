    class DisplayPaneCommands
    {	public const int foo;    }
