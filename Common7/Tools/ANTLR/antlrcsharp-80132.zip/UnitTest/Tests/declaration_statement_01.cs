int minimumHelpTextColumn = 5;
