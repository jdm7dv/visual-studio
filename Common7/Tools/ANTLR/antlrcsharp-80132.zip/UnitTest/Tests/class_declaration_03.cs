    class DisplayPaneCommands
    {
        static public string[] Forward;
		public string Forward;
        public const string Forward;
        public string Forward		   = "Backwards";
        public const double Sideways   = 1234;
        public const string Sideways   = 1.234;
        public const string Sideways   = 1.234f;
        public const string Sideways   = 0x1234;
//        public const string Back       = 0.ToString();
        public const string Back       = null;
		public string Foo			= SomeFunction();
        public const string FindInPage = "FindInPage";
        public const string Cut        = "Cut";
        public const string Copy       = "Copy";
        public const string Paste      = "Paste";
        public const string Print      = "Print";
        public const string PageDown   = "PageDown";
        public const string SelectAll  = "SelectAll";
        public const string RenameSelection = "RenameSelection";
        public const string NextSearchResult = "NextSearchResult";
        public const string PrevSearchResult = "PrevSearchResult";
    }
