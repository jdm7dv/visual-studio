
[SecurityPermission(SecurityAction.LinkDemand,UnmanagedCode=true)]
    internal class GenericArraySortHelper<TKey, TValue>
        : IArraySortHelper<TKey, TValue> 
        where TKey : IComparable<TKey>
{

}
#if !FEATURE_PAL
#else // !FEATURE_PAL

 #if !PLATFORM_UNIX 
 //       //internal const String DLLPREFIX = "";
 //       //internal const String DLLSUFFIX = ".dll"; 
 #else // !PLATFORM_UNIX
  #if __APPLE__
 //       //internal const String DLLPREFIX = "lib";
 //       //internal const String DLLSUFFIX = ".dylib"; 
 // #elif _AIX
 //       //internal const String DLLPREFIX = "lib";
 //       //internal const String DLLSUFFIX = ".a"; 
  #elif __hppa__ || IA64
 //       //internal const String DLLPREFIX = "lib"; 
 //       //internal const String DLLSUFFIX = ".sl";
 // #else
 //       //internal const String DLLPREFIX = "lib";
 //       //internal const String DLLSUFFIX = ".so"; 
  #endif
 #endif // !PLATFORM_UNIX 
#endif
