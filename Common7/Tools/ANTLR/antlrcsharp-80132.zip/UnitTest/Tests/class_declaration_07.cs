    class App : System.Windows.Application 
    {

	public Foo.bar.baz<string>.FOO foo;        
	public Foo<string,string>.bar.baz<string>.FOO foo;        
    public event EventHandler<ParserActionEventArgs> ActionSelected;
        public bool? InitializeComponent()
        {
        }
	}