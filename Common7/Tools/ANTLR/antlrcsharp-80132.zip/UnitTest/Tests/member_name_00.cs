System.Collections.ICollection<Type>.Copy
