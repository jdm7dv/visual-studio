(int[])Mouse.Foo
