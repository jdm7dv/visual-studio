*(src + len) = 0;


