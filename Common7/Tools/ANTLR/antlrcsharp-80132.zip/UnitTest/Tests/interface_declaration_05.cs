    /// <summary>
    /// Defines additional functions for display panes.
    /// </summary>
    /// <since>2.0</since>
    //public 
    interface IDisplayPane2: IDisplayPane
    {
        /// <summary>
        /// Shows the data of the specified resource in the display pane and highlights
        /// the specified words in its text.
        /// </summary>
        /// <param name="resource">The resource to display.</param>
        /// <param name="wordsToHighlight">The array of references to words to be highlighted. May be <c>null</c>, which means that no words should be highlighted and Display Pane's behavior should default to <see cref="IDisplayPane.DisplayResource(IResource)"/>.</param>
        /// <remarks>
        /// <para>The array is sorted by section and then by offset within the section.</para>
        /// <para>This overload incapsulates the behavior of <see cref="IDisplayPane.DisplayResource(IResource)"/> and <see cref="IDisplayPane.HighlightWords"/> in order to provide the optimized performance.</para>
        /// </remarks>
        void DisplayResource( IResource resource, WordPtr[] wordsToHighlight );
        int AddRemoteCall(string rcName, string tokenword);
    }
