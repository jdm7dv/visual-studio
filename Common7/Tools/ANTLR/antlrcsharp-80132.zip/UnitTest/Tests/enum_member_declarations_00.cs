        	// enum_body can have the trailing ','
        PlainText1, 
        PlainText2, 
        PlainText3, 
        PlainText4 = 4, 
        PlainText5 = 7
