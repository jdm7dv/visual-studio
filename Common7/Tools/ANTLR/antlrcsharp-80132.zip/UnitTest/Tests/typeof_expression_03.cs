typeof(foo[])
