    class App : System.Windows.Application 
    {
        
    public event EventHandler<ParserActionEventArgs> ActionSelected;
        public bool? InitializeComponent()
        {
        }
	}