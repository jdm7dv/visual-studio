typeof(foo)
