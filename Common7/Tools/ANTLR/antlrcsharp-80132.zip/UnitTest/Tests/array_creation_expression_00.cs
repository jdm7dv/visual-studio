new Point[3]

