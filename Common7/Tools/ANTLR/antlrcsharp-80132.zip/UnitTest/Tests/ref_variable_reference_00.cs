ref (int) ref foo

