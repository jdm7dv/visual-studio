doc.LoadXml(ref (int) ref foo)

