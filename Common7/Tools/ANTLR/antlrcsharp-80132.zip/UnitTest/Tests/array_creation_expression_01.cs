new System.Point [4]


