3;
foo;
wtf;
foo => foo == bar;