(int)Mouse.Foo
