while (true) 
	foo();

