this is ProxyHwnd ? this : null
