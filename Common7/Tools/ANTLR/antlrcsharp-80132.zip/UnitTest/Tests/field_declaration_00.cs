//internal static readonly Typesa 
ClassTypes
		 = {
            typeof(void),
            typeof(Char),
            typeof(SByte), 
            typeof(Byte),
            typeof(Int16), 
            typeof(UInt16), 
            typeof(Int32),
            typeof(UInt32), 
            typeof(Int64),
            typeof(UInt64),
            typeof(Single),
            typeof(Double), 
            typeof(String),
            typeof(void), 
            typeof(DateTime), 
            typeof(TimeSpan),
            typeof(Object), 
            typeof(Decimal),
            null,  // Enums - what do we do here?
            typeof(Missing),
            typeof(DBNull),
        };
/* */