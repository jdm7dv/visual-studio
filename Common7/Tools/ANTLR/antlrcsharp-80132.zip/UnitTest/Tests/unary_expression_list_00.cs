1;
-1;
--pre;
++pre;
post--;
post++;
Path(args);
visCorners[3];
//();
foo;
foo.bar;
a.b.c.d.e;
foo[];
foo[0];
foo[a];
foo[ab];
foo[ab].bar;
foo[ab].bar[a];
bar[][];
bar[a][];
bar[a][b];
foo();
foo(a);
foo(a,b);
foo[0].foo();
foo[a].foo(a);
foo[ab].foo(a,b);
foo[ab].bar.foo();
foo[ab].bar[a].foo();
(insd)bar;      	// cast
(this.foo).bar;	// paren_expression
(CastMe)Foo.Path(args);
this.foo();
this.foo[0];
this.argumentMap[argument.LongName];
*something;
*(something);	// paren_expression
*(src + len);	// paren expression
