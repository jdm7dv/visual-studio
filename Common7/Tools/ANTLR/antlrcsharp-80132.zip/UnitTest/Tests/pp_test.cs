//#if SHAZAM==BATMAN==ROBIN
#if FOO
#if !FOO
--++ HELLO SHOULD NOT FAIL
#endif
#elif BAAM
++-- will NOT Fail
#else

#if !GAS
public interface Bar{ void member(); }
#else
--++ HELLO SHOULD NOT FAIL
#endif

public class Foo{}
#endif
public interface Bar{ void member(); }
