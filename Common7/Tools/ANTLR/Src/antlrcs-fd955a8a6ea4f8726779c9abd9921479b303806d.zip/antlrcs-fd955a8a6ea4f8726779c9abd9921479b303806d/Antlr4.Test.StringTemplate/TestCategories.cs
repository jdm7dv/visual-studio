﻿namespace Antlr4.Test.StringTemplate
{
    internal static class TestCategories
    {
        public const string ST4 = "ST4";
    }
}
