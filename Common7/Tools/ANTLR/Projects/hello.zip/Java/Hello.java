/***********************************************************************
 *
 *   Hello World   in  Java
 *
 *   Neil Johnson, 2004, Cambridge University Computer Laboratory
 *
 *   Build:
 *            javac Hello.java
 *
 **********************************************************************/

public class Hello 
{
    public static void main(String[] args)
    {
        System.out.print("Hello world.\n");
    }
}

