////////////////////////////////////////////////////////////////////////
//
//  Hello World   in  C#
//
//  Neil Johnson, 2004, Cambridge University Computer Laboratory
//
//  Build:
//          csc Hello.cs
//
////////////////////////////////////////////////////////////////////////

using System;

public class HelloApp
{
    public static void Main()
    {
        Console.WriteLine( "Hello World!" );
    }
}

