/************************************************************************
 *
 * HelloWorld  in  C
 *
 * Neil Johnson, 2004, Cambridge University Computer Laboratory
 *
 * Build:    gcc hello.c -o hello
 *
 ************************************************************************/

#include <stdio.h>

int main( void )
{
    puts( "Hello World!" );

    return 0;
}

