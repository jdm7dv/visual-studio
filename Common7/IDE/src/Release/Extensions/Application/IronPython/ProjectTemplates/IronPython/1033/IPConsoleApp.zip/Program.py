hello = "Hello VSX!!!"

print hello