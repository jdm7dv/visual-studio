﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Общими сведениями о сборке управляет следующий набор атрибутов.
// Измените значения этих атрибутов, чтобы изменить сведения, связанные со сборкой.
[assembly: AssemblyTitle("$safeprojectname$")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("$registeredorganization$")]
[assembly: AssemblyProduct("$safeprojectname$")]
[assembly: AssemblyCopyright("Copyright © $registeredorganization$ $year$")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: CLSCompliant(true)]

// Установка атрибута ComVisible в значение false делает типы в этой сборке невидимыми для COM-компонентов.
// Чтобы получить доступ к типу в этой сборке из модели COM, установите атрибут ComVisible для этого типа в значение true.
[assembly: ComVisible(false)]

// Следующий идентификатор GUID представляет идентификатор typelib, если этот проект доступен из модели COM
[assembly: Guid("$guid1$")]

[assembly: NeutralResourcesLanguage("ru-RU")]

// Сведения о версии для сборки состоят из следующих четырех значений:
//
//      Основной номер версии
//      Дополнительный номер версии 
//      Номер сборки
//      Номер редакции
//
// Можно указать все значения или оставить для номера редакции и номера сборки значения по умолчанию, указав символ "*", как показано ниже:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
