﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

// アセンブリの一般的な情報は、以下の属性セットを使用して制御されます。
// アセンブリに関連付けられている情報を変更するには、これらの属性値を変更します。
[assembly: AssemblyTitle("$safeprojectname$")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corp.")]
[assembly: AssemblyProduct("$safeprojectname$")]
[assembly: AssemblyCopyright("Copyright © Microsoft Corp. 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: CLSCompliant(true)]
[assembly: NeutralResourcesLanguage("ja-JP")]

// ComVisible を false に設定すると、その型はこのアセンブリ内で COM コンポーネントから参照不可能になります。
// このアセンブリ内で COM から型にアクセスする必要がある場合は、その型の ComVisible 属性を true に設定してください。
[assembly: ComVisible(false)]

// 次の GUID は、このプロジェクトが COM に公開される場合の、typelib の ID です
[assembly: Guid("$guid1$")]

// アセンブリのバージョン情報は、次の 4 つの値で構成されます:
//
//      メジャー バージョン
//      マイナー バージョン 
//      ビルド番号
//      リビジョン
//
// すべての値を指定するか、次のように '*' を使ってリビジョンおよびビルド番号を既定値にすることができます:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
