﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

// La información general de un ensamblado se controla mediante el siguiente conjunto de atributos.
// Cambie estos valores de atributo para modificar la información asociada a un ensamblado.
[assembly: AssemblyTitle("$safeprojectname$")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corp.")]
[assembly: AssemblyProduct("$safeprojectname$")]
[assembly: AssemblyCopyright("Copyright © Microsoft Corp. 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: CLSCompliant(true)]
[assembly: NeutralResourcesLanguage("es-ES")]

// Si establece ComVisible en false, los tipos de este ensamblado no estarán visibles para los componentes COM.
// Si necesita obtener acceso a un tipo de este ensamblado desde COM, establezca el atributo ComVisible en true para ese tipo.
[assembly: ComVisible(false)]

// El siguiente GUID sirve como identificador de la typelib si este proyecto se expone a COM
[assembly: Guid("$guid1$")]

// La información de versión de un ensamblado consta de los cuatro valores siguientes:
//
//      Versión principal
//      Versión secundaria 
//      Número de compilación
//      Revisión
//
// Puede especificar todos los valores o establecer como predeterminados los números de versión de compilación y de revisión mediante el asterisco (*), tal y como se muestra a continuación:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
