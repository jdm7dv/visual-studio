﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

// Allgemeine Informationen über eine Assembly werden durch den folgenden Satz von Attributen gesteuert.
// Ändern Sie diese Attributwerte, um die einer Assembly zugeordneten Informationen zu ändern.
[assembly: AssemblyTitle("$safeprojectname$")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corp.")]
[assembly: AssemblyProduct("$safeprojectname$")]
[assembly: AssemblyCopyright("Copyright © Microsoft Corp. 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: CLSCompliant(true)]
[assembly: NeutralResourcesLanguage("de-DE")]

// Durch das Festlegen von ComVisible auf "false" sind die Typen in dieser Assembly für COM-Komponenten nicht sichtbar.
// Wenn Sie von COM aus auf einen Typ in dieser Assembly zugreifen möchten, muss das ComVisible-Attribut für diesen Typ auf "true" festgelegt werden.
[assembly: ComVisible(false)]

// Die folgende GUID ist für die ID der typelib vorgesehen, wenn dieses Projekt für COM verfügbar gemacht wird.
[assembly: Guid("$guid1$")]

// Versionsinformationen für eine Assembly bestehen aus folgenden vier Werten:
//
//      Hauptversion
//      Nebenversion 
//      Buildnummer
//      Revision
//
// Sie können alle Werte festlegen oder die Revisions- und Buildnummer wie nachfolgend gezeigt mithilfe von "*" auf den Standardwert festlegen:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
