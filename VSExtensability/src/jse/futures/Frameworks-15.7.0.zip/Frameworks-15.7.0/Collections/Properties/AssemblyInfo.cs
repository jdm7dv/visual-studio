using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Bridge.Collections")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("Bridge.Collections")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("2a995530-b40e-42b5-a949-014c1186967e")]
[assembly: AssemblyVersion("1.3")]
[assembly: AssemblyFileVersion("1.3.3")]
[assembly: AssemblyInformationalVersion("1.3.3")]