﻿namespace Bridge.WebGL
{
    /// <summary>
    /// The texture object.
    /// </summary>
    [External]
    public class WebGLTexture { }
}
