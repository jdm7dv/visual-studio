using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Bridge.WebGL")]
[assembly: AssemblyProduct("Bridge.WebGL")]
[assembly: AssemblyDescription("WebGL (Web Graphics Library) version 1.x bindings for Bridge.NET.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("99243041-ec64-4e8d-8f3a-ad822b81caa9")]
[assembly: AssemblyVersion("1.8")]
[assembly: AssemblyFileVersion("1.8.2")]
[assembly: AssemblyInformationalVersion("1.8.2")]