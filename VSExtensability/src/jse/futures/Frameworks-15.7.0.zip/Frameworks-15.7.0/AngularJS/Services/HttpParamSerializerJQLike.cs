namespace Bridge.AngularJS.Services
{
    /// <summary>
    /// The $httpParamSerializerJQLike service.
    /// </summary>
    [External]
    public class HttpParamSerializerJQLike
    {
        /// <summary>
        /// 
        /// </summary>
        /// <see cref="!:https://docs.angularjs.org/api/ng/service/$httpParamSerializerJQLike">
        /// Official JavaScript Documentation
        /// </see>
        [Template("$httpParamSerializerJQLike()")]
        public static void DoHttpParamSerializerJQLike()
        {
            return;
        }
    }
}