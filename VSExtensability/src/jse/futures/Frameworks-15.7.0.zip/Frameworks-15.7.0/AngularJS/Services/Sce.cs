namespace Bridge.AngularJS.Services
{
    /// <summary>
    /// The $sce service.
    /// </summary>
    [External]
    public class Sce
    {
        /// <summary>
        /// 
        /// </summary>
        /// <see cref="!:https://docs.angularjs.org/api/ng/service/$sce">
        /// Official JavaScript Documentation
        /// </see>
        [Template("$sce()")]
        public static void DoSce()
        {
            return;
        }
    }
}