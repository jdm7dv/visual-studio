﻿namespace Bridge.AngularJS
{
    /// <summary>
    /// Extension methods for the ngChange directive.
    /// </summary>
    [External]
    public partial class AngularInputElement : AngularElement
    {
        /// <summary>
        /// Gets the current textual value of ng-change (ngChange)
        /// directive bound to the element, if any.
        /// </summary>
        /// <returns>String value the element currently has.</returns>
        /// <see cref="!:https://docs.angularjs.org/api/ng/directive/ngChange">
        /// Official JavaScript documentation.
        /// </see>
        [Template("{this}.getAttribute('ng-change')")]
        public extern string GetChange();
        
        /// <summary>
        /// Sets a textual value to the ng-change (ngChange)
        /// directive on the element.
        /// </summary>
        /// <param name="value">Value to bind to the directive.</param>
        /// <see cref="!:https://docs.angularjs.org/api/ng/directive/ngChange">
        /// Official JavaScript documentation.
        /// </see>
        [Template("{this}.setAttribute('ng-change', {value})")]
        public extern void SetChange(string value);

        /// <summary>
        /// Removes the ng-change (ngChange) directive definition
        /// from the element.
        /// </summary>
        /// <see cref="!:https://docs.angularjs.org/api/ng/directive/ngChange">
        /// Official JavaScript documentation.
        /// </see>
        [Template("{this}.removeAttribute('ng-change')")]
        public extern void RemoveChange();
    }
}