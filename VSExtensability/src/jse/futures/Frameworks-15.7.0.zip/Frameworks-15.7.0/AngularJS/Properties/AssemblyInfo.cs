using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Bridge.AngularJS")]
[assembly: AssemblyProduct("Bridge.AngularJS")]
[assembly: AssemblyDescription("AngularJS version 1.x bindings for Bridge.NET.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("9d045fc6-7afd-4746-bd42-1612f96c86ff")]
[assembly: AssemblyVersion("1.1")]
[assembly: AssemblyFileVersion("1.1.2")]
[assembly: AssemblyInformationalVersion("1.1.2")]