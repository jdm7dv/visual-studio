using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Bridge.Bootstrap3")]
[assembly: AssemblyProduct("Bridge.Bootstrap3")]
[assembly: AssemblyDescription("Bootstrap version 3.x bindings for Bridge.NET.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("ebd43cb4-1057-4dc5-9a7e-78c96c08b2c9")]
[assembly: AssemblyVersion("3.9.3")]
[assembly: AssemblyFileVersion("3.9.3")]
[assembly: AssemblyInformationalVersion("3.9.3")]