using System.Reflection;

[assembly: AssemblyCompany("Object.NET, Inc.")]
[assembly: AssemblyCopyright("Copyright 2008-2016 Object.NET, Inc.")]
