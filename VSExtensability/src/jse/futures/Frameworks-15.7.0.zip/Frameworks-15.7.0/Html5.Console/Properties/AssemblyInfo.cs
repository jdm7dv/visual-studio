﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Bridge.Html5.Console")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("Bridge.Html5.Console")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("49a43430-680d-4704-9105-d4352d105b86")]
[assembly: AssemblyVersion("1.0")]
[assembly: AssemblyFileVersion("1.0.3")]
[assembly: AssemblyInformationalVersion("1.0.3")]