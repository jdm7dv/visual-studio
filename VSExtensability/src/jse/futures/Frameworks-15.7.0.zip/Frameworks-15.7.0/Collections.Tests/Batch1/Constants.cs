﻿namespace Bridge.Collections.ClientTest
{
    static class Constants
    {
        public const string BRIDGE_ISSUES = "Bridge Issues";
        public const string COLLECTIONS = "Collections";
    }
}
