using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Bridge.Collections client tests")]
[assembly: AssemblyProduct("Bridge.Collections client tests")]
[assembly: AssemblyDescription("Bridge.Collections test library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("13940d0b-c16d-40b6-ba71-18c9eb086832")]