namespace Bridge.jQuery2
{
    public partial class jQuery
    {
        /// <summary>
        /// The number of elements in the jQuery object.
        /// </summary>
        public readonly int Length;
    }
}
