using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Bridge.jQuery2")]
[assembly: AssemblyProduct("Bridge.jQuery2")]
[assembly: AssemblyDescription("jQuery version 2.x bindings for Bridge.NET.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("92c5fd07-ea24-489d-8fe4-692cab8ab447")]
[assembly: AssemblyVersion("2.9")]
[assembly: AssemblyFileVersion("2.9.2")]
[assembly: AssemblyInformationalVersion("2.9.2")]