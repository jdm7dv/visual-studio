using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Bridge.QUnit")]
[assembly: AssemblyProduct("Bridge.QUnit")]
[assembly: AssemblyDescription("QUnit version 1.x bindings for Bridge.NET.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("4e022916-4840-44a9-a9db-dd6c961ce29d")]
[assembly: AssemblyVersion("1.8")]
[assembly: AssemblyFileVersion("1.8.2")]
[assembly: AssemblyInformationalVersion("1.8.2")]